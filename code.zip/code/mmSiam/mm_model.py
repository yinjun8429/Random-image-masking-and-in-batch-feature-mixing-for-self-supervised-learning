from torch import nn
import torch
from .mm_resnet import ResNet18, ResNet34, ResNet50, ResNet101, ResNet152
import numpy as np

class projection_MLP(nn.Module):
    def __init__(self, in_dim, out_dim, num_layers=2):
        super().__init__()
        hidden_dim = out_dim
        self.num_layers = num_layers

        self.layer1 = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True)
        )

        self.layer2 = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True)
        )
        self.layer3 = nn.Sequential(
            nn.Linear(hidden_dim, out_dim),
            nn.BatchNorm1d(out_dim, affine=False)  # Page:5, Paragraph:2
        )

    def forward(self, x):
        if self.num_layers == 2:
            x = self.layer1(x)
            x = self.layer3(x)
        elif self.num_layers == 3:
            x = self.layer1(x)
            x = self.layer2(x)
            x = self.layer3(x)

        return x


class prediction_MLP(nn.Module):
    def __init__(self, in_dim=2048):
        super().__init__()
        out_dim = in_dim
        hidden_dim = int(out_dim / 4)

        self.layer1 = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True)
        )
        self.layer2 = nn.Linear(hidden_dim, out_dim)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)

        return x
    
class mmSiam(nn.Module):
    def __init__(self, args):
        super(mmSiam, self).__init__()

        
        self.backbone = mmSiam.get_backbone(args.arch)
        out_dim = self.backbone.fc.weight.shape[1]
        self.backbone.fc = nn.Identity()

        self.projector = projection_MLP(out_dim, args.feat_dim,
                                        args.num_proj_layers)

        self.encoder = nn.Sequential(
            self.backbone,
            self.projector
        )

        self.predictor = prediction_MLP(args.feat_dim)
        

        
    def mixup_data(self, x, alpha):
        '''Returns mixed inputs, pairs of targets, and lambda'''
        x_flip = x.flip(0).clone()
        
        mixed_x = (1-alpha) * x + alpha * x_flip
        
        return mixed_x

    @staticmethod
    def get_backbone(backbone_name):
        return {'resnet18': ResNet18(),
                'resnet34': ResNet34(),
                'resnet50': ResNet50(),
                'resnet101': ResNet101(),
                'resnet152': ResNet152()}[backbone_name]

    def forward(self, im_aug1, im_aug2, im_aug3):
       
        alpha=0.4
        
        z1 = self.encoder(im_aug1)
        z2 = self.encoder(im_aug2)
        z3 = self.encoder(im_aug3)
        
        p1 = self.predictor(z1)
        p2 = self.predictor(z2)
        p3 = self.predictor(z3)
        
        z1_mix = self.mixup_data(z1, alpha)
        z2_mix = self.mixup_data(z2, alpha)
       
        
        p1_mix = self.predictor(z1_mix)
        p2_mix = self.predictor(z2_mix)
        

    
       
        return {'z1': z1, 'z2': z2, 'z3': z3, 'z1_mix': z1_mix, 'z2_mix': z2_mix, 'p1': p1, 'p2': p2, 'p3': p3,'p1_mix': p1_mix, 'p2_mix': p2_mix}

        