from torch import nn
import torch
import numpy as np

class mmSiamLoss(nn.Module):
    def __init__(self, version='simplified'):
        super().__init__()
        self.ver = version
        # normalization layer for the representations z1 and z2
        self.bn = nn.BatchNorm1d(2048, affine=False)
    def asymmetric_loss(self, p, z):
        if self.ver == 'original':
            z = z.detach()  # stop gradient

            p = nn.functional.normalize(p, dim=1)
            z = nn.functional.normalize(z, dim=1)

            return -(p * z).sum(dim=1).mean()

        elif self.ver == 'simplified':
            z = z.detach()  # stop gradient
            return - nn.functional.cosine_similarity(p, z, dim=-1).mean()
    
    def forward(self, z1, z2, z3, z1_mix, z2_mix, p1, p2, p3, p1_mix, p2_mix):

        loss1 = self.asymmetric_loss(p1, z2)
        loss2 = self.asymmetric_loss(p2, z1)
        loss_sourse = 0.5 * loss1 + 0.5 * loss2
        
        loss3 = self.asymmetric_loss(p1_mix, z2) 
        loss4 = self.asymmetric_loss(p1_mix, z2_mix) 
        loss_mix = 0.5*loss3 + 0.5*loss4
        
        loss5 = self.asymmetric_loss(p1, z3)
        loss6 = self.asymmetric_loss(p3, z1)
        loss_mask = 0.5 * loss5 + 0.5 * loss6
        
        loss = loss_sourse + loss_mix + loss_mask
        return loss


